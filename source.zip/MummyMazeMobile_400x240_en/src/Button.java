/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Thinh
 */
public class Button {
    
    public static final int COMMAND_NONE = 0;
    public static final int COMMAND_UP = 1;
    public static final int COMMAND_RIGHT = 5;
    public static final int COMMAND_DOWN = 6;
    public static final int COMMAND_LEFT = 2;
    public static final int COMMAND_FIRE = 8;
    public static final int COMMAND_UNDO = -10;
    public static final int COMMAND_RESTART = -11;
    public static final int COMMAND_QUICKMENU = -12;
    
    protected int command = COMMAND_NONE;
    private int x, y, width, height;
    
    public Button(int command, int x, int y, int width, int height) {
        this.command = command;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
    
    public boolean contains(int x, int y) {
        if (x >= this.x && x <= (this.x + width)) {
            if (y >= this.y && y <= this.y + height) {
                return true;
            }
        }
        return false;
    }
}
