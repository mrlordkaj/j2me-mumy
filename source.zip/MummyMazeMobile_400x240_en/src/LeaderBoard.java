/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import InneractiveSDK.IADView;
import helpers.ImageHelper;
import helpers.NetworkHelper;
import helpers.StringHelper;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import javax.microedition.io.ConnectionNotFoundException;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.GameCanvas;

/**
 *
 * @author Thinh
 */
public class LeaderBoard extends GameCanvas {

    private Main parent;
    private Image background, frontground;
    private StringBuffer content = new StringBuffer();
    private boolean err = false;
    private int marginTop = 0, stepY = 0;
    private Timer timer;
    private Vector ads;
    private boolean loaded = false, preload = false;

    public LeaderBoard(Main mainMidlet) {
        super(false);
        parent = mainMidlet;
        setFullScreenMode(true);
        startTimer();
    }
    
    private void startTimer() {
        timer = new Timer();
        timer.schedule(new TimerTask() {
            public void run() {
                if(!preload) {
                    preload = true;
                    prepareResource();
                    try {
                        loadScoreBoard();
                        ads = IADView.getBannerAdData(parent, "Openitvn_MummyMazeDeluxe_Nokia");
                    } catch (Exception ex) {
                        ads = null;
                    }
                }
                repaint();
            }
        }, 0, 60);
    }

    public void paint(Graphics g) {
        if (!loaded) {
            g.setColor(0, 0, 0);
            g.fillRect(0, 0, Main.DIMENSION_WIDTH, Main.DIMENSION_HEIGHT);
            return;
        }
        g.drawImage(background, Main.DIMENSION_WIDTH / 2, Main.DIMENSION_HEIGHT / 2 + 12, Graphics.HCENTER | Graphics.VCENTER);
        g.setColor(255, 255, 255);
        g.setFont(Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL));
        if (content.length() > 0) {
            StringHelper.drawScoreBoard(g, content, 124, 58 + marginTop);
        } else {
            if (!err) {
                g.drawString("fetching data...", Main.DIMENSION_WIDTH / 2, Main.DIMENSION_HEIGHT / 2, Graphics.BASELINE | Graphics.HCENTER);
            } else {
                g.drawString("connection failed!", Main.DIMENSION_WIDTH / 2, Main.DIMENSION_HEIGHT / 2, Graphics.BASELINE | Graphics.HCENTER);
            }
        }
        g.drawImage(frontground, 0, 0, Graphics.TOP | Graphics.LEFT);
        try {
            g.drawImage((Image) ads.elementAt(0), 0, 0, Graphics.TOP | Graphics.LEFT);
        } catch (Exception ex) {
        }
    }

    protected void pointerPressed(int x, int y) {
        //close
        if (x >= 250 && x <= 290) {
            if (y >= 205 && y <= 235) {
                parent.gotoMainMenu();
                return;
            }
        }
        
        try {
            if (x >= 0 && x <= ((Image) ads.elementAt(0)).getWidth()) {
                if (y >= 0 && y <= ((Image) ads.elementAt(0)).getHeight()) {
                    parent.platformRequest((String) ads.elementAt(1));
                    return;
                }
            }
        } catch (ConnectionNotFoundException ex) {
        } catch (Exception ex) {
        }
        
        stepY = y - marginTop;
    }

    protected void pointerReleased(int x, int y) {
        int lineHeight = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL).getHeight();
        if (marginTop > 0) {
            marginTop = 0;
        } else if (marginTop < -lineHeight * 91) {
            marginTop = -lineHeight * 91;
        }
    }

    protected void pointerDragged(int x, int y) {
        marginTop = y - stepY;
    }

    private void prepareResource() {
        background = ImageHelper.loadImage("/images/leaderboardbackground.png");
        frontground = ImageHelper.loadImage("/images/leaderboard.png");
        loaded = true;
    }

    private void loadScoreBoard() {
        try {
            content = NetworkHelper.getContentViaHttp("http://m.openitvn.net/java.php?id=" + Main.SERVER_ID + "&passkey=" + Main.SERVER_PASSKEY + "&record=100");
            repaint();
        } catch (IOException ex) {
            err = true;
        } catch (Exception ex) {
            err = true;
        }
    }

    public void dispose() {
        loaded = false;
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
        background = null;
        frontground = null;
        content = null;
        if (ads != null && !ads.isEmpty()) {
            ads.removeAllElements();
            ads = null;
        }
    }
}
